This directory contains all of your static media.
