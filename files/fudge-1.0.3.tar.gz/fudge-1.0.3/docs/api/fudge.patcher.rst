
.. _fudge.patcher:

-------------
fudge.patcher
-------------

.. automodule:: fudge.patcher

.. autofunction:: fudge.patcher.with_patched_object

.. autofunction:: fudge.patcher.patched_context

.. autofunction:: fudge.patcher.patch_object
   
.. autoclass:: fudge.patcher.PatchHandler
   :members: