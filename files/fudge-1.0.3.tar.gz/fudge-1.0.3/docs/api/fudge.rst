
-----
fudge
-----

.. automodule:: fudge

.. autofunction:: fudge.patch

.. autofunction:: fudge.test

.. autoclass:: fudge.Fake
   :members:

.. autofunction:: fudge.clear_calls

.. autofunction:: fudge.verify

.. autofunction:: fudge.with_fakes
   
.. autoclass:: fudge.FakeDeclarationError
   :members: