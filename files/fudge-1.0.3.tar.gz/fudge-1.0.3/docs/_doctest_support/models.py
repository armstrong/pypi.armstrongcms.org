
# this is so the SQLAlchemy doctest will work. 
    
class User(object):
    id = 1