import unittest
from gateway_tests import *
from authorize_net_tests import *
from pay_pal_tests import *
from eway_tests import *
from world_pay_tests import *
from google_checkout_tests import *
from amazon_fps_tests import *
from braintree_payments_tests import *
from braintree_payments_tr_tests import *

if __name__ == "__main__":
    unittest.main()
