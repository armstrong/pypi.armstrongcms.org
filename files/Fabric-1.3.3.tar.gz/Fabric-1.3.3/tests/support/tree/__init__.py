from fabric.api import task

import system, db


@task
def deploy():
    pass

@task
def build_docs():
    pass
