=====
Tasks
=====

.. automodule:: fabric.tasks
    :members: Task, execute
