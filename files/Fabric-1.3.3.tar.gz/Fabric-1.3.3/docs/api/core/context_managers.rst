================
Context Managers
================

.. automodule:: fabric.context_managers

    .. autofunction:: cd(path)
    .. autofunction:: hide(*groups)
    .. autofunction:: lcd(path)
    .. autofunction:: path
    .. autofunction:: prefix
    .. autofunction:: settings
    .. autofunction:: show(*groups)
