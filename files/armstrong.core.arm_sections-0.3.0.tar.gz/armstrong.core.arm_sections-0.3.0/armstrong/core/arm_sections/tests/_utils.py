from datetime import datetime
from django.core.files import File
from django.conf import settings

from armstrong.dev.tests.utils import ArmstrongTestCase
from armstrong.dev.tests.utils.concrete import *
from armstrong.dev.tests.utils.users import *

import fudge


class ArmSectionsTestCase(ArmstrongTestCase):
    pass
