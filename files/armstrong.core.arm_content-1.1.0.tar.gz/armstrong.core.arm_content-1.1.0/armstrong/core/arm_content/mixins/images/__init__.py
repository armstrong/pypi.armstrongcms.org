from .base import BaseThumbnailMixin, ImageMixin
from .sorl import SorlThumbnailMixin
